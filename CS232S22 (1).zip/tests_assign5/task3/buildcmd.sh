#!/bin/bash
cmd="make"
executable="mystring-test"
