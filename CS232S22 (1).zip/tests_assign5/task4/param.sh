#!/bin/bash
expected="construct_3_structs.c Makefile snode.h"
