#!/bin/bash
cmd="make song_list"
executable="song_list"
