#!/bin/bash
cmd="gcc -Wall -std=c11 wordstats.c -o wordstats"
executable="wordstats"
