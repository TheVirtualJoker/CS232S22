#!/bin/bash
cmd="gcc -Wall -std=c11 bubble.c -o bubble"
executable="bubble"
