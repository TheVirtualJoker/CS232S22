g++ --std=c++11 -g labyrinth/*.cpp -o ./simple_labyrinth
