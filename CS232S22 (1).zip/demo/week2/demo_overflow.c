#include<stdio.h>

int main(void) {
  char var = 0;
  for(var=0; var<=255; var++) {
      printf("%d", var);
  }

  return 0;
}
