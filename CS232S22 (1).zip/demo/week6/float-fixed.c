#include <stdio.h>

int main(void) {
	if(1.1f-1.1 < 0.00001) {
		printf("1.1f == 1.1\n");
	} else {
		printf("1.1f != 1.1\n");
	}; 

	if(2.0f == 2.0) {
		printf("2.0f == 2.0\n");
	} else {
		printf("2.0f != 2.0\n");
	}; 
}
