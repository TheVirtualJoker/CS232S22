#!/bin/bash
expected="get_bits.c test_get_bits.c"
