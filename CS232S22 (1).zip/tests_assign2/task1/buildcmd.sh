#!/bin/bash
cmd="./build.sh"
executable="intro"
